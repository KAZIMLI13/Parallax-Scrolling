# CSS-3D-clickable-flip-cards

Your task is to work on **CSS 3D clickable flip cards**. Here you can find the sample **HTML** (structure) and **CSS** (SCSS) styling. To visualize the code you can use the online IDE: [CodePen (https://codepen.io).](https://codepen.io)  Do not forget to change the CSS Preprocessor setting to SCSS (see the settings.png).

We need you to read/understand the code and to use your creativity to design your **own version** of flip cards to promote/advertise a product. **Good Luck!**
